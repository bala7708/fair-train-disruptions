Put openrefine-operations.json here (OpenRefine: Undo / Redo -> Extract... -> Export).
